<?php
require 'config/db.php';
$msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $price = $_POST['price'];
    $quantity = $_POST['quantity'];

    if (!$name || !is_numeric($price) || !is_numeric($quantity)) {
        $msg = "Invalid input.";
    } else {
        $stmt = $pdo->prepare("INSERT INTO products (name, price, quantity) VALUES (?, ?, ?)");
        $stmt->execute([$name, $price, $quantity]);
        header('Location: index.php');
        exit;
    }
}
?>
<!DOCTYPE html>
<html>
<head><title>Add Product</title></head>
<body>
<h2>Add Product</h2>
<form method="POST">
Name: <input type="text" name="name"><br>
Price: <input type="text" name="price"><br>
Quantity: <input type="text" name="quantity"><br>
<button>Add</button>
</form>
<?php if ($msg): ?><p style="color:red;"><?= $msg ?></p><?php endif; ?>
</body>
</html>