<?php
require 'config/db.php';

$id = $_GET['id'] ?? null;
if (!$id) {
    header('Location: index.php');
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
$stmt->execute([$id]);
$product = $stmt->fetch();

if (!$product) {
    echo "Product not found.";
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $price = $_POST['price'];
    $quantity = $_POST['quantity'];

    if ($name && is_numeric($price) && is_numeric($quantity)) {
        $stmt = $pdo->prepare("UPDATE products SET name = ?, price = ?, quantity = ? WHERE id = ?");
        $stmt->execute([$name, $price, $quantity, $id]);
        header('Location: index.php');
        exit;
    } else {
        $error = "Invalid input.";
    }
}
?>
<!DOCTYPE html>
<html>
<head><title>Edit Product</title></head>
<body>
<h2>Edit Product</h2>
<?php if (!empty($error)) echo "<p style='color:red;'>$error</p>"; ?>
<form method="POST">
    Name: <input type="text" name="name" value="<?= htmlspecialchars($product['name']) ?>"><br>
    Price: <input type="text" name="price" value="<?= $product['price'] ?>"><br>
    Quantity: <input type="text" name="quantity" value="<?= $product['quantity'] ?>"><br>
    <button>Update</button>
</form>
</body>
</html>