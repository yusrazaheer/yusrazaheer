<?php
require 'config/db.php';

$search = $_GET['search'] ?? '';
$page = $_GET['page'] ?? 1;
$limit = 10;
$offset = ($page - 1) * $limit;

$sql = "SELECT * FROM products WHERE name LIKE :search LIMIT $limit OFFSET $offset";
$stmt = $pdo->prepare($sql);
$stmt->execute(['search' => '%' . $search . '%']);
$products = $stmt->fetchAll();

$total = $pdo->query("SELECT COUNT(*) FROM products")->fetchColumn();
$pages = ceil($total / $limit);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Product List</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<h1>Products</h1>
<form method="GET">
    <input type="text" name="search" placeholder="Search" value="<?= htmlspecialchars($search) ?>">
    <button>Search</button>
</form>
<a href="add.php">Add New Product</a> | 
<a href="functions/excel_export.php">Export to Excel</a> | 
<a href="upload.php">Import Excel</a>
<table border="1">
<tr><th>ID</th><th>Name</th><th>Price</th><th>Qty</th><th>Action</th></tr>
<?php foreach ($products as $p): ?>
<tr>
<td><?= $p['id'] ?></td>
<td><?= $p['name'] ?></td>
<td><?= $p['price'] ?></td>
<td><?= $p['quantity'] ?></td>
<td>
    <a href="edit.php?id=<?= $p['id'] ?>">Edit</a> | 
    <a href="delete.php?id=<?= $p['id'] ?>" onclick="return confirm('Sure?')">Delete</a>
</td>
</tr>
<?php endforeach; ?>
</table>
<div>
<?php for ($i = 1; $i <= $pages; $i++) echo "<a href='?page=$i'>$i</a> "; ?>
</div>
</body>
</html>